const mysql = require("mysql");
const express = require("express");
const bodyParser = require("body-parser");

const encoder = bodyParser.urlencoded({extended:true});

const app = express();

app.use(express.urlencoded({ 
    extended: true 
}));

app.use(express.json());

app.use("/src",express.static("src"));

const connection =  mysql.createConnection({
    host: "localhost",
    user: "root",
    password:  "admin",
    database: "nodejs"
});

connection.connect(function(error){
    if(error) throw error
    else console.log("connected to the database successfully!")
});

app.get("/",function(req,res){
    res.sendFile(__dirname + "/login.html")
});

app.post("/", encoder, function(req, res) {
    var username = req.body.username;
    var password = req.body.password;

    connection.query("SELECT * FROM loginuser WHERE user_name = ? AND user_pass = ?", [username, password], function(error, results, fields) {
        if (results.length > 0) {
            res.redirect("/index");
        } else {
            res.redirect("/");
        }
        res.end();
    });
});

app.get("/index",function(req,res){

    res.sendFile(__dirname + "/index.html")
});

app.get('/reserve_room', function(req, res) {
    res.sendFile(path.join(__dirname, 'public', 'reserve_room.html'));
});

app.listen(4500);